# UDEMY_DeepLearning_covid19
Repositorio con los scripts necesarios para relaizar el despliegue de un modelo de Deep Learning para el análisis de imágenes médicas construido en Keras+Tensorflow.
Se utiliza Flask para exponer un servicio web de tipo REST.
